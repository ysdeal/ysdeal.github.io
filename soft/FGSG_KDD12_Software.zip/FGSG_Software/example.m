% example
clear all
clc
addpath('Cfiles');
fprintf('An example.....\n');

p = 500;
n = 200;
g = 150;

tol = 1e-3;
aTol = 1e-3;
maxIter = 100;
aMaxIter = 1000;
tau = 0.15;
rho = 5;

E = randomGraph(p,g);

% Note E is 2 x g matrix.  
E = E';

% set opts
opts.tol = tol;
opts.maxIter = maxIter;
opts.aMaxIter = aMaxIter;
opts.aTol = aTol;
opts.tau = tau;
opts.rho = rho;
opts.wt = ones(1,g);
opts.x0 = zeros(p,1);   % initial solution

% generate data
A = randn(n,p);
x0 = randn(p,1);
y = A * x0 + 0.01 * randn(n, 1);

% set regularization parameter
s1 = 0.8*max(abs(x0));
s2 = s1;

tic
x1= goscar(A,y,E, s1,s2,opts);
toc
tic
x2= ncFGS(A,y,E, s1,s2,opts);
toc
tic
x3= ncTFGS(A,y,E, s1,s2,opts);
toc
tic
x4 = gflasso(A,y,E, s1,s2,opts);
toc

tic
x5= ncTL(A,y,E, s1,s2,opts);
toc
tic
x6= ncTF(A,y,E, s1,s2,opts);
toc
tic
x7= ncTLF(A,y,E, s1,s2,opts);
toc

% simply set opts as [] to use default values
opts=[];

x11= goscar(A,y,E, s1,s2,opts);

x21= ncFGS(A,y,E, s1,s2,opts);

x31= ncTFGS(A,y,E, s1,s2,opts);

x41 = gflasso(A,y,E, s1,s2,opts);

x51= ncTL(A,y,E, s1,s2,opts);

x61= ncTF(A,y,E, s1,s2,opts);

x71= ncTLF(A,y,E, s1,s2,opts);