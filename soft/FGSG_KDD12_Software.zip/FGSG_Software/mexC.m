% 
fprintf('make sure you have set up the C complier, see "help mex"\n');
fprintf('mex C files, please wait....\n');
current_dir = cd;
cd([current_dir '/Cfiles']);
cc = mex.getCompilerConfigurations('Any','Selected');
if isunix
    mex('-largeArrayDims', 'goscar.c', '-lmwblas','-lmwlapack');
	mex('-largeArrayDims', 'ncFGS.c', '-lmwblas','-lmwlapack');
	mex('-largeArrayDims', 'ncTFGS.c', '-lmwblas','-lmwlapack');
	mex('-largeArrayDims', 'gflasso.c', '-lmwblas','-lmwlapack');
	mex('-largeArrayDims','ncTL.c', '-lmwblas','-lmwlapack');
    mex('-largeArrayDims','ncTF.c', '-lmwblas','-lmwlapack');
    mex('-largeArrayDims','ncTLF.c', '-lmwblas','-lmwlapack');
else
    if strcmp(getenv('PROCESSOR_ARCHITECTURE'),'AMD64')
        blaslib = fullfile(matlabroot, 'extern', 'lib', 'win64',...
            'microsoft', 'libmwblas.lib');
        lapacklib = fullfile(matlabroot, 'extern', 'lib', 'win64',...
            'microsoft', 'libmwlapack.lib');
    elseif strcmp(cc.Manufacturer, 'LCC')
        blaslib = fullfile(matlabroot, 'extern', 'lib', 'win32',...
            'lcc', 'libmwblas.lib');
        lapacklib = fullfile(matlabroot, 'extern', 'lib', 'win32',...
            'lcc', 'libmwlapack.lib');
    else
        blaslib = fullfile(matlabroot, 'extern', 'lib', 'win32',...
            'microsoft', 'libmwblas.lib');
        lapacklib = fullfile(matlabroot, 'extern', 'lib', 'win32',...
            'microsoft', 'libmwlapack.lib');
    end
    mex('-largeArrayDims', 'goscar.c', blaslib,lapacklib);
    mex('-largeArrayDims','ncFGS.c', blaslib,lapacklib)
    mex('-largeArrayDims','ncTFGS.c', blaslib,lapacklib)
    mex('-largeArrayDims', 'gflasso.c', blaslib,lapacklib);
    mex('-largeArrayDims','ncTL.c', blaslib,lapacklib)
    mex('-largeArrayDims','ncTF.c', blaslib,lapacklib)
    mex('-largeArrayDims','ncTLF.c', blaslib,lapacklib)

end
cd(current_dir);