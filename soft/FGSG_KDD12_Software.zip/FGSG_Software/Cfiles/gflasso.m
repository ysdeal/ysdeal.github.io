% Function x = gflasso(A,y,E,s1,s2,opts)
%       graph fused lasso
%
%% Problem
%
%  min 1/2 ||Ax - y||^2 + s1*||x||_1 + s2*\sum_{(i,j)\in E}w_(i,j)|x_i - r_(i,j)x_j|
%  w_(i,j) is the weight of edge (i,j), r_(i,j) is the sign of correlation between x_i
%  and x_j. w, r can be specified in opts.wt (default value is a vector of 1).
%
%% Input parameters:
%
%  A -                 Matrix of size n x p
%  y -                 Response vector of size n x 1
%  E -                 a set of edges (size of 2 x g)
%  s1-                 L_1 norm regularization parameter ( s1 >=0 )
%  s2-                 Grouping regularization parameter (s2 >=0)
%  opts -              Optional inputs (defualt value: opts=[]);
%       - aMaxIter     maximum number of iterations of ADMM (default value: 1000)
%       - aTol         tolerance of ADMM (default value: 1e-3)
%       - x0           initial solution (dimension must be p, default value: opts.x0 = 0)
%       - wt           weight and sign, w = abs(opts.wt), and r = sign(opts.wt) (dimension must be g) 
%       - rho          the dual update length for ADMM (default value: 5)
%
%% Output parameters
%  x -         Solution
%
%  For any problem, please contact with Sen Yang via senyang@asu.edu
%
%  Last modified on June 13, 2012.
%
%% Related papers
%
%  Kim, S. and Xing, E.P., Statistical estimation of correlated genome 
%  associations to a quantitative trait network, PLoS genetics, 2009.