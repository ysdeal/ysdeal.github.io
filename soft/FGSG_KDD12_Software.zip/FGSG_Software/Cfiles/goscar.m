% Function x = goscar(A,y,E,s1,s2,opts)
%       graph OSCAR
%
%% Problem
%
%  min 1/2 ||Ax - y||^2 + s1*||x||_1 + s2*\sum_{(i,j)\in E}w_{(i,j)}max{|x_i|,|x_j|}
%  where w_(i,j) is the weight of edge (i,j), which can be specified in 
%  opts.wt (default value is 1)
%% Input parameters:
%
%  A -                 Matrix of size n x p
%  y -                 Response vector of size n x 1
%  E -                 a set of edges (size of 2 x g)
%  s1-                 L_1 norm regularization parameter ( s1 >=0 )
%  s2-                 Pairwise L_\infty regularization parameter (s2 >=0)
%  opts -              Optional inputs (defualt value: opts=[]);
%       - aMaxIter     maximum number of iterations of ADMM (default value: 1000)
%       - aTol         tolerance for convergence in ADMM (default value: 1e-3)
%       - x0           initial solution (dimension must be p, default value: opts.x0 = 0)
%       - wt           weight w = abs(opts.wt) (dimension must be g) 
%       - rho          the dual update length for ADMM (default value: 5)
%
%% Output parameters
%  x -         Solution
%
%  For any problem, please contact with Sen Yang via senyang@asu.edu
%
%  Last modified on June 13, 2012.
%
%% Related papers
%
%  Sen Yang, Lei Yuan, Ying-Cheng Lai, Xiaotong Shen, Peter Wonka, and Jieping Ye, 
%  Feature Grouping and Selection over an Undirected Graph, KDD, 2012