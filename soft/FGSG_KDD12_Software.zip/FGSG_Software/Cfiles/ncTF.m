% Function x = ncTF(A,y,E,s1,s2,opts)
%       Non-Convex Truncated Fused Feature Grouping and Selection
%
%% Problem
%
%  min 1/2 || Ax - y ||^2 + s1*p_1(x) + s2*p_2(x)
%  where
%    p_1(x) = sum_i(|x_i|)
%    p_2(x) = s2*\sum_{(i,j)\in E}w_(i,j)J_\tau(|x_i - r_(i,j)x_j|)
%    J_\tau (x) = min(x/\tau,1) is a surrogate of the L0 norm
%    \tau is tuning parameter for J_\tau, default value 0.15
%    w_(i,j) is the weight of edge (i,j), r_(i,j) is the sign of correlation between x_i
%    and x_j. w, r can be specified in opts.wt (default value is a vector of 1).
%
%% Input parameters:
%
%  A -                 Matrix of size n x p
%  y -                 Response vector of size n x 1
%  E -                 a set of edges (size of 2 x g)
%  s1-                 L_1 norm regularization parameter ( s1 >=0 )
%  s2-                 Grouping regularization parameter (s2 >=0)
%  opts -              Optional inputs (defualt value: opts=[]);
%       - aMaxIter     maximum number of iterations of subproblem (ADMM) (default value: 1000)
%       - aTol         tolerance of subproblem (ADMM) (default value: 1e-3) 
%       - maxIter      maximum number of iterations of DC programming (default value: 100)
%       - tol          tolerance of DC programming (default value: 1e-3) 
%       - x0           initial solution (dimension must be p, default value: opts.x0 = 0)
%       - wt           weight and sign, w = abs(opts.wt), and r = sign(opts.wt) (dimension must be g) 
%       - rho          the dual update length for ADMM (default value: 5)
%       - tau          the tuning parameter for J_\tau (default 0.15)
%
%% Output parameters
%  x -         Solution
%  funVal-     Function value during iterations
%
%  For any problem, please contact with Sen Yang via senyang@asu.edu
%
%  Last modified on June 13, 2012.
%
%% Related papers
%