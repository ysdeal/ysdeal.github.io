#include "mexrel.h"
#include "fgsg.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	double *A, *y, *x, *tp, *temp, s1, s2;
	size_t *edge, i;
	size_t flag = 0;
	Parm opts;

	A  =  mxGetPr(prhs[0]);
	y  =  mxGetPr(prhs[1]);
	tp = mxGetPr(prhs[2]);
	s1 = (double) mxGetScalar(prhs[3]);
	s2 = (double) mxGetScalar(prhs[4]);
	opts.n = (size_t)mxGetM(prhs[0]);
	opts.p = (size_t)mxGetN(prhs[0]);
	opts.g = (size_t)mxGetN(prhs[2]);

	opts.maxIter = (size_t) getScalarStruct(prhs[5],"maxIter", 100);
	opts.rho     = getScalarStruct(prhs[5], "rho", 5);
	opts.tol     = getScalarStruct(prhs[5], "tol", 1e-3);
	opts.wt      = getPointerStruct(prhs[5],"wt");
	temp         = getPointerStruct(prhs[5],"x0");
	opts.aTol    = getScalarStruct(prhs[5], "aTol", 1e-3);
	opts.aMaxIter = (size_t) getScalarStruct(prhs[5],"aMaxIter", 1000);
	
	if (!opts.wt)
	{
	    flag = 1;
		opts.wt = (double*) mxMalloc(opts.g * sizeof (double));
		for (i = 0; i< opts.g; i++)
			opts.wt[i] = 1;
	}
	else
       for (i = 0; i<opts.g; i++)
           opts.wt[i] = fabs(opts.wt[i]);

	edge = (size_t *)mxMalloc( 2*opts.g*sizeof(size_t) );
	for (i = 0; i<2*opts.g; i++)
		edge[i] = (size_t) tp[i] - 1;

	plhs[0] = mxCreateDoubleMatrix(opts.p, 1, mxREAL);
	x = mxGetPr(plhs[0]);
	
	if (temp)
		memcpy(x,temp,opts.p*sizeof(double));

	ncFGS(A,y,x,edge,s1,s2,opts);
	if (flag)
		mxFree(opts.wt);
	mxFree(edge);
}
