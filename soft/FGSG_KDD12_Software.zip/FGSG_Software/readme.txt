Updates:
    - 3 functions are added:  ncTL, ncTF, and ncTLF
    - initial solution can be specified for all functions: opts.x0
    - Changes of convergence criterion (ADMM and DC share the same convergence criterion in the old version. They are separated now) 
      -- aMaxIter and aTol for ADMM
      -- maxIter and tol for DC

Please refer the manual for more details.