This package includes fast implementations for multiple precision matrices estimation: fused multiple graphical lasso, group multiple graphical lasso. 

Reference:
S. Yang, Z. Lu, X. Shen, P. Wonka, and J. Ye, Fused Multiple Graphical Lasso, SIAM Journal on Optimization, to appear, 2015