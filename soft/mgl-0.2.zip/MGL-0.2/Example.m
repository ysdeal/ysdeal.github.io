clc
clear all
addpath(genpath('Code'));
K = 5;
n = 500;

% params 
% only params.lambda, params.rho are required. The other parameters will be
% set by default value if they are not specified. 
params.sigma = 1e-3;
params.maxlineiter = 50;
params.maxiter = 50;
params.linesearch = true;
params.SPGmaxiter = 50;
params.SPGreltol = 1e-8;
params.Newtontol = 1e-5;
% NewtonStop 1: only works if you set an objective value, the
% algorithm won't stop util the objective value is smaller than the
% specified one
% NewtonStop 2: stop when subgradient optimial condition, which can be
% checked from output
% NewtonStop 3: stop when relative error is less than Newtontol
params.NewtonStop = 2;
% use adaptive stop condition in NSPG
params.Adaptive = 1;

% fused penalty
params.penalty = 0;
% group penalty
%params.penalty = 1;

% lambda1 and lambda2
params.lambda = 0.1;
params.rho = 0.2;

pert = 1.3;
BL = 5;
        
S = zeros(n,n,K);P =  zeros(n,n,K);
trueSparsity = 0;
for k = 1:K
    bn = n/BL;
    for bs = 1:BL
        St = eye(bn,bn);
        Tr= randomGraph(bn,round(bn*pert));
        St(Tr==1) = 1;
        Ed((bs-1)*bn+1:bs*bn,(bs-1)*bn+1:bs*bn) = St'*St+ eye(bn,bn);
    end
    trueSparsity = trueSparsity + numel(find(Ed~=0));
    [A] = mvnrnd(zeros(n,1),Ed,5*n);
    S(:,:,k) = cov(zscore(A));
    P(:,:,k) = diag(1./diag(S(:,:,k)));
end

[P,funVal,iterTime,subopt] = mgl_adp(S,params);


% Screening
% Compute the block structure
% 1st step: compute the adj matrix, which has the same block structures as
% the solution
adj = globalScreening(S,params.lambda,params.rho,params.penalty);
% the 2nd step: find the connect components of the adj matrix
[Sc, Cc] = graphconncomp(sparse(adj));
% for each connect component, compute the precision matrix
for i = 1:Sc
    idx = find(Cc==i);
    Ssub=S(idx,idx,:);
    [Psub] = mgl_adp(Ssub,params);
end